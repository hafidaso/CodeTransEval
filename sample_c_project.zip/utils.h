#ifndef UTILS_H
#define UTILS_H

// Utility functions
int factorial(int n);
int fibonacci(int n);
void print_array(int arr[], int size);

#endif 